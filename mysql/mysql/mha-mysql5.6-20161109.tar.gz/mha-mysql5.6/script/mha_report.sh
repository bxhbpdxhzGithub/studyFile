#!/bin/sh
### author: guweitao
### date: 2016-11-01
### desc: when mha failover occurs,it can report mail and sms




logfile=/tmp/mha_report.log
date=`date '+%F %T'`
hostname=`hostname`
port=$1

receiver=guweitao@mistong.com
subject='mha failover'


function send_mail()
{
echo "`date '+%F %T'` ${hostname}:${port} mha failover" | mail -s "$subject" $receiver
echo "`date '+%F %T'` ${hostname}:${port} mha failover" >>$logfile
}

function send_sms()
{
	sms_subject="`date +%T` $port mha failover"
        curl "http://sms.zabbix.mistong.com/dba.php?sio=$sms_subject"

}

send_mail
send_sms



