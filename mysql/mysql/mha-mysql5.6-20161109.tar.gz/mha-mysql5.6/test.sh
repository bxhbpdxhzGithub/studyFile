#!/bin/sh


function sb_prepare()
{
sysbench --test=/usr/share/doc/sysbench/tests/db/oltp.lua --oltp-table-size=500000 --oltp-read-only=off --init-rng=on --num-threads=4 --max-requests=0 --oltp-dist-type=uniform --max-time=1800 --mysql-host=10.0.0.16 --mysql-port=3904 --mysql-user=mstdba_mgr  --mysql-password=8ffe3589337b7d35 --db-driver=mysql --mysql-table-engine=innodb --oltp-test-mode=complex prepare

}

function sb_run()
{
 sysbench --test=/usr/share/doc/sysbench/tests/db/oltp.lua --oltp-table-size=500000 --oltp-read-only=off --init-rng=on --num-threads=16 --max-requests=0 --oltp-dist-type=uniform --max-time=180 --mysql-user=mstdba_mgr --mysql-password=8ffe3589337b7d35 --mysql-host=10.0.0.16 --mysql-port=3904 --db-driver=mysql --mysql-table-engine=innodb --oltp-test-mode=complex run

}

sbtype=$1

if [ -z $sbtype ]
then
        echo "$0 prepare|run"
        exit 1

elif [ $sbtype = 'prepare' ];then
        sb_prepare
elif [ $sbtype = 'run' ];then
        sb_run
fi

